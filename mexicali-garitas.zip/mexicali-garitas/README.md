# Garitas Mexicali — tiempos de espera en vivo

Página con los tiempos de espera oficiales de CBP para las dos garitas de
Mexicali (Calexico West = "Garita Centro", Calexico East = "Garita Nueva"),
contador de visitas y chat comunitario con fotos, todo corriendo sobre
Netlify (sitio estático + funciones serverless + Netlify Blobs como base
de datos, sin necesidad de contratar nada externo).

## Qué incluye

- `index.html` — la página (diseño, fetch de datos, chat, contador).
- `netlify/functions/wait-times.js` — obtiene datos reales de
  `https://bwt.cbp.gov/api/waittimes` (API pública de CBP) y los filtra a
  solo las 2 garitas de Mexicali, en las 4 categorías: Normal, SENTRI,
  Ready Lane y Peatonal.
- `netlify/functions/counter.js` — contador de visitas persistente.
- `netlify/functions/chat.js` — chat comunitario: guarda mensajes con
  límite de 24h, con protección anti-spam (límite de frecuencia por IP,
  bloqueo temporal tras 3 mensajes marcados como spam, filtro de enlaces
  y texto repetido).
- `netlify.toml` / `package.json` — configuración para que Netlify
  reconozca las funciones y sus dependencias.

## Cómo publicarlo en Netlify (gratis)

**Opción rápida — arrastrar y soltar (no necesitas saber de código):**

1. Ve a https://app.netlify.com y crea una cuenta (gratis).
2. En el dashboard, busca la zona que dice "Deploy manually" / arrastra
   una carpeta.
3. Arrastra la carpeta completa `mexicali-garitas` (con todo adentro).
4. Netlify te da una URL tipo `algo-random.netlify.app` — ya está en línea.
5. Ve a **Site settings → Domain management** para ponerle un nombre más
   bonito (ej. `garitas-mexicali.netlify.app`) gratis.

Con "deploy manually" Netlify normalmente sí detecta y sube las funciones
en `netlify/functions/` automáticamente. Si notas que `/.netlify/functions/`
da error 404, usa la opción con GitHub de abajo, que instala las
dependencias (`@netlify/blobs`) antes de desplegar y es más confiable.

**Opción recomendada — conectar con GitHub (se actualiza solo):**

1. Sube esta carpeta a un repositorio de GitHub (puede ser privado).
2. En Netlify: **Add new site → Import an existing project → GitHub**,
   selecciona el repo.
3. Build command: déjalo vacío. Publish directory: `.` (ya está en
   `netlify.toml`, Netlify lo detecta solo).
4. Deploy. Netlify instala `@netlify/blobs` automáticamente y activa las
   funciones.

**Netlify Blobs** (donde se guardan el contador y el chat) viene activado
por defecto en cualquier sitio de Netlify, no necesitas configurar nada
extra ni pagar por una base de datos aparte.

## Mantenimiento / mejoras que valdría la pena agregar después

- **Moderación manual**: ahora mismo cualquiera puede publicar; si crece
  el uso, conviene agregar una función `delete-message` protegida con una
  contraseña para poder borrar un mensaje ofensivo sin esperar el borrado
  de 24h.
- **Notificaciones**: un botón de "avísame cuando baje el tiempo de esta
  línea" usando notificaciones push del navegador.
- **Historial/gráfica**: guardar snapshots cada hora para mostrar una
  mini-gráfica de "cómo ha estado la fila hoy", útil para planear a qué
  hora cruzar.
- **Multi-idioma**: agregar toggle ES/EN, ya que cruzan personas de ambos
  lados.
- **Service worker**: para que cargue instantáneo en visitas repetidas
  desde el celular.

## Nota importante sobre la sección de donaciones

En el HTML dejé la sección "Apoyar la página" con un botón placeholder
(`#donateLink`) en vez de datos de pago reales. Ve el mensaje en el chat
para la razón — en resumen, publicar un número de tarjeta directamente en
una página pública no es seguro. Usa un enlace de PayPal.me, Mercado Pago,
Buy Me a Coffee, o similar, y pon ese link en `id="donateLink"`.

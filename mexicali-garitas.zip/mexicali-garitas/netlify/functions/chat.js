const { getStore } = require("@netlify/blobs");

const DAY_MS = 24 * 60 * 60 * 1000;
const MIN_GAP_MS = 15 * 1000;       // min time between posts from same IP
const BLOCK_MS = 60 * 60 * 1000;    // block duration after repeated spam
const MAX_MESSAGES = 200;           // cap stored messages
const MAX_TEXT = 280;
const MAX_NAME = 24;
const MAX_IMAGE_CHARS = 700000;     // ~500KB after base64 overhead

const BANNED_PATTERNS = [
  /https?:\/\/\S+/i,                 // no external links in chat
  /\b(viagra|casino|porn|xxx|crypto\s*airdrop|prestamo\s*facil|gana\s*dinero)\b/i,
  /(.)\1{9,}/,                        // 10+ repeated identical chars ("aaaaaaaaaa")
];

function getIp(event) {
  return (
    event.headers["x-nf-client-connection-ip"] ||
    (event.headers["x-forwarded-for"] || "").split(",")[0].trim() ||
    "unknown"
  );
}

function isSpammy(text) {
  if (!text) return false;
  return BANNED_PATTERNS.some((re) => re.test(text));
}

function cleanOld(messages) {
  const cutoff = Date.now() - DAY_MS;
  return messages.filter((m) => new Date(m.ts).getTime() > cutoff);
}

exports.handler = async function (event) {
  const chatStore = getStore("chat");
  const guardStore = getStore("chat-guard");

  if (event.httpMethod === "GET") {
    let messages = [];
    try {
      const raw = await chatStore.get("messages", { type: "json" });
      messages = Array.isArray(raw) ? raw : [];
    } catch (e) {
      messages = [];
    }
    messages = cleanOld(messages);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages })
    };
  }

  if (event.httpMethod === "POST") {
    const ip = getIp(event);
    let payload;
    try {
      payload = JSON.parse(event.body || "{}");
    } catch (e) {
      return { statusCode: 400, body: JSON.stringify({ error: "JSON inválido" }) };
    }

    const name = String(payload.name || "Anónimo").trim().slice(0, MAX_NAME) || "Anónimo";
    const garita = String(payload.garita || "").trim().slice(0, 20);
    const lane = String(payload.lane || "").trim().slice(0, 20);
    const text = String(payload.text || "").trim().slice(0, MAX_TEXT);
    const image = payload.image ? String(payload.image) : null;

    if (!text && !image) {
      return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Mensaje vacío" }) };
    }
    if (image && (!image.startsWith("data:image/") || image.length > MAX_IMAGE_CHARS)) {
      return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Imagen no válida o demasiado grande" }) };
    }

    // ---- guard: block list + rate limit + spam strikes ----
    let guard = {};
    try {
      guard = (await guardStore.get(ip, { type: "json" })) || {};
    } catch (e) {
      guard = {};
    }
    const now = Date.now();

    if (guard.blockedUntil && guard.blockedUntil > now) {
      return {
        statusCode: 429,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Se detectó actividad sospechosa. Intenta más tarde." })
      };
    }
    if (guard.lastPost && now - guard.lastPost < MIN_GAP_MS) {
      return {
        statusCode: 429,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Espera unos segundos antes de enviar otro mensaje." })
      };
    }

    const spammy = isSpammy(text) || (guard.lastText && text && text === guard.lastText);
    if (spammy) {
      const strikes = (guard.strikes || 0) + 1;
      guard.strikes = strikes;
      guard.lastPost = now;
      if (strikes >= 3) {
        guard.blockedUntil = now + BLOCK_MS;
        guard.strikes = 0;
      }
      await guardStore.set(ip, JSON.stringify(guard));
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Mensaje bloqueado por parecer spam." })
      };
    }

    // ---- passed checks: store message ----
    let messages = [];
    try {
      const raw = await chatStore.get("messages", { type: "json" });
      messages = Array.isArray(raw) ? raw : [];
    } catch (e) {
      messages = [];
    }
    messages = cleanOld(messages);
    messages.push({
      id: now + "-" + Math.random().toString(36).slice(2, 8),
      name,
      garita,
      lane,
      text,
      image: image || undefined,
      ts: new Date(now).toISOString()
    });
    if (messages.length > MAX_MESSAGES) {
      messages = messages.slice(messages.length - MAX_MESSAGES);
    }
    await chatStore.set("messages", JSON.stringify(messages));

    guard.lastPost = now;
    guard.lastText = text;
    guard.strikes = 0;
    await guardStore.set(ip, JSON.stringify(guard));

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: true })
    };
  }

  return { statusCode: 405, body: "Method not allowed" };
};

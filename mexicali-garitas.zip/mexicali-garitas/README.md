# Garitas Mexicali — tiempos de espera en vivo

Página con los tiempos de espera oficiales de CBP para las dos garitas de
Mexicali, contador de visitas y chat comunitario con fotos — **todo
funciona 100% del lado del navegador, sin servidor**, como los guestbooks
de foros viejos. Usa KVdb.io (una base de datos pública gratis con API
REST) para que el chat y el contador se compartan entre todos los
visitantes sin necesitar Netlify Functions, GitHub, ni `npm install`.

## Antes de publicarla: un solo paso

1. Abre `crear-bucket.html` en tu navegador (doble clic basta, no necesita
   estar en línea todavía).
2. Pon tu correo y dale "Crear base de datos". Te va a dar un ID largo,
   tipo `Fd55uogXyxYdnXJvnyN8Xo`.
3. Copia ese ID y pégalo en `index.html`, en la línea:
   ```js
   const BUCKET_ID = "PON_AQUI_TU_BUCKET_ID";
   ```
4. Guarda, y ya puedes borrar `crear-bucket.html` (o dejarlo, no estorba).

Ese "cajón" (bucket) es público sin contraseña — cualquiera con el ID
puede leer y escribir, que es justo lo que queremos para un chat abierto.
Si algún día quieres protegerlo, KVdb permite agregarle una `write_key`
después (ver kvdb.io/docs).

## Qué incluye

- `index.html` — la página completa (diseño, tiempos, chat, contador).
- `crear-bucket.html` — utilidad de un solo uso para crear el bucket.
- `netlify/functions/wait-times.js` — **opcional**: si algún día
  despliegas en Netlify, esta función sirve los tiempos de CBP ya
  filtrados y cacheados. Si no la despliegas, la página igual funciona
  gracias al respaldo que jala los datos directo desde el navegador.
- `netlify.toml` / `package.json` — solo relevantes si usas la función
  opcional de arriba.

## Cómo publicarla (ahora sí, cualquier hosting sirve)

Como ya no depende de funciones de servidor para el chat, puedes usar
literalmente cualquier hosting estático:

**Netlify (arrastrar y soltar, como antes):**
1. Ve a app.netlify.com → arrastra la carpeta `mexicali-garitas`.
2. Listo, ya no importa que no corra `npm install` — el chat no lo
   necesita.

**Cualquier otro hosting estático** (GitHub Pages, Vercel, Cloudflare
Pages, tu propio hosting) también funciona igual de bien, solo sube
los archivos.

## Límites de este enfoque (para que no te agarren en curva)

- **Fotos muy chicas**: KVdb limita cada valor a 16KB, así que las fotos
  se comprimen fuerte (thumbnails de ~200px). No vas a poder mandar
  fotos grandes y nítidas con este método.
- **Anti-spam más débil**: como todo corre en el navegador de cada
  quien, el filtro de spam y el límite de "espera 15 segundos" se pueden
  saltar editando el código en las herramientas de desarrollador. Para
  un chat comunitario chico esto normalmente no es problema, pero no es
  tan robusto como un filtro de servidor.
- **El bucket es público**: cualquiera con el ID (que queda visible en
  el código fuente de la página) puede escribir o borrar mensajes. Es el
  mismo trato que un guestbook viejo — abierto para todos, sin dueño
  técnico controlando cada mensaje.
- **1,000 peticiones por hora por IP** es el límite gratis de KVdb — de
  sobra para un chat comunitario normal.

## Nota sobre la sección de donaciones

La tarjeta de "Apoya esta página" ya trae tu CLABE puesta. Si más
adelante prefieres Mercado Pago o quieres quitarla, solo edita esa
sección en `index.html` (busca `class="card"`).


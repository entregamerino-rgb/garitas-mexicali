const { getStore } = require("@netlify/blobs");

exports.handler = async function (event) {
  try {
    const store = getStore("stats");
    const shouldCount = event.queryStringParameters && event.queryStringParameters.count === "1";

    let total = parseInt((await store.get("visits")) || "0", 10);
    if (isNaN(total)) total = 0;

    if (shouldCount) {
      total += 1;
      await store.set("visits", String(total));
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ total })
    };
  } catch (err) {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ total: 0 })
    };
  }
};

// Fetches official CBP border wait times and returns only the Mexicali (Calexico) crossings,
// simplified into Normal / SENTRI / Ready Lane / Pedestrian for the front end.

const CBP_URL = "https://bwt.cbp.gov/api/waittimes";

// Calexico East = Garita Nueva (Mexicali II), Calexico West = Garita Centro (Mexicali I)
const PORTS = [
  { number: "250302", label: "Garita Centro", note: "Calexico West · Mexicali I" },
  { number: "250301", label: "Garita Nueva", note: "Calexico East · Mexicali II" }
];

function num(v) {
  if (v === undefined || v === null || v === "" || v === "N/A") return null;
  const n = parseInt(v, 10);
  return isNaN(n) ? null : n;
}

function laneStatus(raw) {
  if (!raw) return { delay: null, lanesOpen: null, status: "na", updated: "" };
  const opStatus = (raw.operational_status || "").toLowerCase();
  if (opStatus.includes("closed")) {
    return { delay: null, lanesOpen: null, status: "closed", updated: "" };
  }
  if (opStatus === "n/a" || opStatus === "" || opStatus.includes("update pending")) {
    return { delay: null, lanesOpen: null, status: "na", updated: "" };
  }
  return {
    delay: num(raw.delay_minutes),
    lanesOpen: num(raw.lanes_open),
    status: "open",
    updated: raw.update_time || ""
  };
}

exports.handler = async function () {
  try {
    const res = await fetch(CBP_URL, {
      headers: { "User-Agent": "Mozilla/5.0 (garitas-mexicali dashboard)" }
    });
    if (!res.ok) throw new Error("CBP responded " + res.status);
    const all = await res.json();

    const ports = PORTS.map((p) => {
      const entry = all.find((x) => x.port_number === p.number);
      if (!entry) {
        return {
          label: p.label,
          note: p.note,
          hours: "",
          normal: laneStatus(null),
          sentri: laneStatus(null),
          readyLane: laneStatus(null),
          pedestrian: laneStatus(null)
        };
      }
      const pv = entry.passenger_vehicle_lanes || {};
      const ped = entry.pedestrian_lanes || {};
      return {
        label: p.label,
        note: p.note,
        hours: entry.hours || "",
        normal: laneStatus(pv.standard_lanes),
        sentri: laneStatus(pv.NEXUS_SENTRI_lanes),
        readyLane: laneStatus(pv.ready_lanes),
        pedestrian: laneStatus(ped.standard_lanes)
      };
    });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=60"
      },
      body: JSON.stringify({
        fetchedAt: new Date().toLocaleString("es-MX", { timeZone: "America/Tijuana" }) + " (hora Mexicali)",
        ports
      })
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "No se pudo obtener datos de CBP", detail: String(err) })
    };
  }
};
